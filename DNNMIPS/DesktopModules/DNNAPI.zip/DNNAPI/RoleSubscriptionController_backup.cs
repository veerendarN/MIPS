﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace DNNAPI
//{
//    class RoleSubscriptionController
//    {
//    }
//}

using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using DotNetNuke.Web.Api;
using DNNAPI.Entity;

using DNNAPI.Models;
using System;
using System.Data;
using System.Net.Http.Headers;
using System.Text;

namespace DNNAPI
{
    [AllowAnonymous]
    public class RoleSubscriptionController : DnnApiController
    {
        //[DnnAuthorize]
        //[HttpGet]
        //public HttpResponseMessage GetHelloWorld()
        //{
        //    var name = "HelloWorld";

        //    return Request.CreateResponse(HttpStatusCode.OK, name);

        //}

        [DnnAuthorize]
        [HttpGet]
        public List<MeasureData> GetAllMeasures()
        {
            var MeasureDataList = new List<MeasureData>();

            using (var entity = new DNN8Entities())
            {

                MeasureDataList = (from mes in entity.vw_QPPMeasures_With_Modality

                                   select new MeasureData
                                   {
                                       MeasureNumber = mes.Measure_Num,
                                       MeasureTitle = mes.Measure_Title,
                                       messageDesc = mes.Measure_Description,
                                       DisplayOrder = mes.DisplayOrder,
                                       MeasureTypeDesc = mes.Message_Desc,
                                       MopdalityDesc = mes.Modality,
                                       RegsitryDesc = mes.Registry,
                                       SpecialtyDesc = mes.specialty_Desc,
                                       measureTypeCode = mes.Measure_Type_Code,
                                       measure_priority = mes.Measure_Priority,
                                       Measure_URL = mes.Measure_URL,
                                       Message2 = mes.Message2

                                   }).OrderBy(m => m.DisplayOrder).ToList();
            }
            return MeasureDataList;
        }


        [DnnAuthorize]
        [HttpGet]
        public List<List<string>> GetAllLookUpsData()
        {
            var globalList = new List<List<string>>();
            var listRegistgryStrings = new List<string>();

            using (var entity = new DNN8Entities())
            {

                listRegistgryStrings = entity.tbl_Lookup_Specialty.Select(i => i.Description).ToList();
                globalList.Add(listRegistgryStrings);
                listRegistgryStrings = new List<string>();


                listRegistgryStrings = entity.tbl_Lookup_QPP_Modality.Select(i => i.Modality).ToList();
                globalList.Add(listRegistgryStrings);
                listRegistgryStrings = new List<string>();

                listRegistgryStrings = entity.tbl_Lookup_Registry.Select(i => i.Description).ToList();
                listRegistgryStrings.RemoveAt(5);
                listRegistgryStrings.Insert(0, "Merit-Based Incentive Payment System");
                globalList.Add(listRegistgryStrings);



                listRegistgryStrings = entity.tbl_Lookup_QPP_Measure_Type.Select(i => i.Description).ToList();
                globalList.Add(listRegistgryStrings);
                listRegistgryStrings = new List<string>();
                return globalList;

            }

        }


        [DnnAuthorize]
        [HttpGet]
        public List<MeasureData> GetAllSelectedMeasures(string arrayOfValues) //,string[] chkModality,string[] chkRegistry,string chkSpeciality)
        {

            var MeasureDataList = new List<MeasureData>();

            var listarray = arrayOfValues.Split(',').Select(i => i).ToArray();

            try
            {
                using (var entity = new DNN8Entities())
                {

                    var mtc = (from n in entity.tbl_Lookup_QPP_Measure_Type where listarray.Contains(n.Description) select n.QPP_Measure_Type_Code).ToList();

                    if (mtc.Count > 0)
                    {

                        MeasureDataList = (from m in entity.vw_QPPMeasures_With_Modality
                                           where mtc.Contains(m.Measure_Type_Code)
                                           select new MeasureData
                                           {
                                               MeasureNumber = m.Measure_Num,
                                               MeasureTitle = m.Measure_Title,
                                               DisplayOrder = m.DisplayOrder,

                                           }).ToList();

                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return MeasureDataList;
        }


        [DnnAuthorize]
        [HttpGet]
        public List<MeasureData> GetSelectionMeasures(string strMeasureType, string strModality = "", string strRegistry = "", string strSpecialty = "")
        //public List<vw_QPPMeasures_With_Modality> GetSelectionMeasures(string strMeasureType, string strModality = "", string strRegistry = "", string strSpecialty = "")
        {
            var measuresList = new List<MeasureData>();
            var mtc = new List<string>();
            var md = new List<string>();
            var reg = new List<string>();
            var spec = new List<string>();
            var listarray = new List<string>();
            var listarraymd = new List<string>();
            var listarrayreg = new List<string>();
            var listarrayspec = new List<string>();
            var blnContainsHP = false;
            var mesNumList = new List<string>();
            var mesNumList2 = new List<string>();
            var strMessage = "";

            using (var entity = new DNN8Entities())
            {
                mesNumList = (from m in entity.vw_QPPMeasures_With_Modality select m.Measure_Num).Distinct().ToList();
                if (mesNumList.Count > 0)
                {
                    mesNumList2 = mesNumList;

                    // measure code type
                    if (!string.IsNullOrEmpty(strMeasureType))
                    {
                        listarray = strMeasureType.Split(',').Select(i => i).ToList();
                        mtc = (from n in entity.tbl_Lookup_QPP_Measure_Type where listarray.Contains(n.Description) select n.QPP_Measure_Type_Code).ToList();
                        foreach (var mt in mtc)
                        {

                            if (mt.Equals("HP"))
                            {
                                blnContainsHP = true;

                            }
                        }


                        if (blnContainsHP)
                        {
                            var hpList = new List<string>();
                            hpList.Add("!");
                            hpList.Add("!!");
                            mesNumList = (from mtlist in entity.vw_QPPMeasures_With_Modality
                                          where (
                                            (mtc.Contains(mtlist.Measure_Type_Code)
                                            || (hpList.Contains(mtlist.Measure_Priority))
                                            ) && mesNumList2.Contains(mtlist.Measure_Num)
                                            )
                                          select mtlist.Measure_Num).Distinct().ToList();
                        }
                        else
                        {
                            mesNumList = (from mtlist in entity.vw_QPPMeasures_With_Modality
                                          where (
                                            mtc.Contains(mtlist.Measure_Type_Code)
                                             && mesNumList2.Contains(mtlist.Measure_Num)
                                            )
                                          select mtlist.Measure_Num).Distinct().ToList();
                            strMessage += "mtype: " + strModality + ":" + Convert.ToString(mesNumList.Count) + " Arraylist: " + Convert.ToString(listarraymd.Count);
                        }

                        mesNumList2 = mesNumList;

                    }


                    // modality
                    if (!string.IsNullOrEmpty(strModality))
                    {
                        listarraymd = strModality.Split(',').Select(i => i).ToList();
                        mesNumList = (from vmmodality in entity.vw_QPPMeasures_With_Modality
                                      where listarraymd.Contains(vmmodality.Modality)
                                      && mesNumList2.Contains(vmmodality.Measure_Num)
                                      select vmmodality.Measure_Num).Distinct().ToList();

                        strMessage += "Modality: " + strModality + ":" + Convert.ToString(mesNumList.Count) + " Arraylist: " + Convert.ToString(listarraymd.Count);
                        mesNumList2 = mesNumList;
                    }

                    //registry
                    if (!string.IsNullOrEmpty(strRegistry))
                    {
                        var Descriptonlist = new List<string>();
                        Descriptonlist = strRegistry.Split(',').Select(i => i).ToList(); //Description list.
                        Descriptonlist = Descriptonlist.Select(s => s.Replace("Merit Based Incentive Payment System", "Merit-Based Incentive Payment System")).ToList();
                        var codes = entity.tbl_Lookup_Registry.Select(c => c).ToList();//Codes List.
                        foreach (var item in Descriptonlist)
                        {
                            //Getting Codes from tbl_Registry table based on selected Description.
                            listarrayreg.Add(codes.Where(c => c.Description == item).Select(c => c.Code).FirstOrDefault());

                        }
                        mesNumList = (from vmRegistry in entity.vw_QPPMeasures_With_Modality
                                      where listarrayreg.Contains(vmRegistry.Registry)
                                       && mesNumList2.Contains(vmRegistry.Measure_Num)
                                      select vmRegistry.Measure_Num).Distinct().ToList();
                        strMessage += "reg: " + strModality + ":" + Convert.ToString(mesNumList.Count) + " Arraylist: " + Convert.ToString(listarrayreg.Count);

                        mesNumList2 = mesNumList;
                    }
                    // Specialty
                    if (!string.IsNullOrEmpty(strSpecialty))
                    {
                        listarrayspec = strSpecialty.Split(',').Select(i => i).ToList();
                        spec = (from m in entity.tbl_Lookup_Specialty where listarrayspec.Contains(m.Description) select m.Code).ToList();
                        mesNumList = (from vmspecialty in entity.vw_QPPMeasures_With_Modality
                                      where spec.Contains(vmspecialty.Specialty)
                                       && mesNumList2.Contains(vmspecialty.Measure_Num)
                                      select vmspecialty.Measure_Num).Distinct().ToList();

                        strMessage += "spec: " + strModality + ":" + Convert.ToString(mesNumList.Count) + " Arraylist: " + Convert.ToString(listarrayspec.Count);
                        mesNumList2 = mesNumList;
                    }
                    //Final

                    measuresList = (from mes in entity.vw_QPPMeasures_With_Modality
                                    where (mesNumList.Contains(mes.Measure_Num))
                                    select new MeasureData
                                    {
                                        MeasureNumber = mes.Measure_Num,
                                        MeasureTitle = mes.Measure_Title,
                                        messageDesc = mes.Message_Desc,
                                        DisplayOrder = mes.DisplayOrder,
                                        measureTypeCode = mes.Measure_Type_Code,
                                        measure_priority = mes.Measure_Priority,
                                        Measure_URL = mes.Measure_URL,
                                        Message2 = mes.Message2
                                    }).OrderBy(m => m.DisplayOrder).ToList();

                }
                //var x = new MeasureData();
                //x.MeasureNumber = strMeasureType + " [Total Result: " + Convert.ToString(measuresList.Count) + "List Array" + Convert.ToString(listarray.Count());
                //x.MeasureTitle = string.Join(",", mtc.ToArray()) + strMessage;
                //x.DisplayOrder = Int32.Parse("99999");
                //measuresList.Add(x);
            }
            return measuresList;
        }

        [DnnAuthorize]
        [HttpGet]
        public HttpResponseMessage GetHP(string Code)
        {
            var resu = string.Empty;
            try
            {
                if (!string.IsNullOrEmpty(Code))
                {


                    using (var entity = new DNN8Entities())
                    {
                        resu = entity.tbl_Lookup_QPP_Measure_Type.Where(i => i.QPP_Measure_Type_Code == Code).Select(x => x.Description).FirstOrDefault();
                        if (resu != null)
                        {
                            return Request.CreateResponse(HttpStatusCode.OK, resu);
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message + "\nInner exception" + Convert.ToString(ex.InnerException) + ex.StackTrace);
            }
            return Request.CreateResponse(HttpStatusCode.OK, resu);
        }


        //[DnnAuthorize]
        //[HttpGet]
        //public HttpResponseMessage ExportToExcel(string strSelectedMeasures)
        //{
        //    string stradd = string.Empty;
        //    List<string> listStrings = new List<string>();
        //    List<ExportToExcelData> exportList = new List<ExportToExcelData>();
        //    DataTable dt = new DataTable();
        //    try
        //    {

        //        if (!string.IsNullOrEmpty(strSelectedMeasures))
        //        {
        //            using (var entity = new DNN8Entities())
        //            {

        //                listStrings = strSelectedMeasures.Split(',').ToList();
        //                stradd = "341:" + stradd + Environment.NewLine;
        //                for (var i = 0; i < listStrings.Count; ++i)
        //                {
        //                    stradd = "344:" + stradd + Environment.NewLine;
        //                    stradd += listStrings[i].ToLower();
        //                    var result = (from v in entity.vw_QPPMeasures_With_Modality
        //                                  where (v.Measure_Num.ToLower() == listStrings[i].ToLower())
        //                                  select new ExportToExcelData
        //                                  {
        //                                      MeasureNumber = v.Measure_Num,
        //                                      MeasureTitle = v.Measure_Title,
        //                                      MeasureType = v.MeasureType_Desc,
        //                                      MesureTypeModifier = v.Measure_Type_Modifier,
        //                                      RegistryDescription = v.registry_Desc,
        //                                      Domain = v.Domain,
        //                                      Speciality = v.specialty_Desc
        //                                  }).FirstOrDefault();


        //                    if (result != null)
        //                    {
        //                        exportList.Add(result);
        //                    }
        //                }//foreach ends.

        //                if (exportList.Count > 0)
        //                {
        //                    stradd = "364:" + stradd + Environment.NewLine;
        //                    dt = Extensions.ToDataTable(exportList);
        //                    stradd = "366:" + stradd + Environment.NewLine;
        //                    System.IO.MemoryStream stream = new System.IO.MemoryStream();
        //                    System.IO.StreamWriter writer = new System.IO.StreamWriter(stream);
        //                    writer.Write("Hello, World!");
        //                    writer.Flush();
        //                    stream.Position = 0;

        //                    HttpResponseMessage response = new HttpResponseMessage(HttpStatusCode.OK);
        //                    response.Content = new StreamContent(stream);
        //                    response.Content.Headers.ContentType = new MediaTypeHeaderValue("text/csv");
        //                    response.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment") { FileName = "Export.csv" };
        //                    // System.IO.Stream spreadsheetStream = new System.IO.MemoryStream();
        //                    // ClosedXML.Excel.XLWorkbook workbook = new ClosedXML.Excel.XLWorkbook();


        //                    //ClosedXML.Excel.IXLWorksheet worksheet = workbook.Worksheets.Add("SHEET");
        //                    // // worksheet.Cell(1, 1).SetValue("example");
        //                    // int celcounter = 0;
        //                    // worksheet.Cell(1 + celcounter, 1).InsertTable(dt);
        //                    // workbook.SaveAs(spreadsheetStream);
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        //var str = ConvertDataTableToString(dt);
        //        return Request.CreateResponse(HttpStatusCode.BadRequest, "Message:[" + ex.Message + "],InnerException:[" + ex.InnerException + "],and datatable:[" + stradd + "],strSelectedMeasures:" + strSelectedMeasures);

        //    }


        //    //var str1 = ConvertDataTableToString(dt);
        //    return Request.CreateResponse(HttpStatusCode.OK, "Selected Measures:[" + strSelectedMeasures + "] and datatable:[" + stradd + "]");
        //}


        [DnnAuthorize]
        [HttpGet]
        public HttpResponseMessage ExportToExcel(int MC, int OC, int PC, int TBP, string SM)
        {
            var data = new ExcelData();
            data.MeasuresCount = MC;
            data.OutcomeCoumt = OC;
            data.PriorityCount = PC;
            data.TotalBonusPoint = TBP;
            data.SelectedMeasures = SM;
            List<string> listStrings = new List<string>();
            string str = "<table border=1 style=font-family:Calibri><tr><td font style='font-weight: bold;'>Total Outcome Selected</td><td>" + data.OutcomeCoumt + "</td></tr><tr><td font style='font-weight: bold;'>Total High-priority Selected</td><td>" + data.PriorityCount + "</td></tr><tr><td font style='font-weight: bold;'>Total Measures Selected</td><td>" + data.MeasuresCount + "</td></tr>";
            str += "<tr> </tr> <tr><td colspan=7 style='color:red'>With your selections you potentially would have " + data.TotalBonusPoint + " bonus points (cap at 10% of total possible quality points; for most radiologists that is 6 points)</td></tr>";
            if (data.TotalBonusPoint < 10)
            {
                str += "<tr><td colspan = 7 style='color:red'> You have not selected enough measures to meet the full requirements; to review other options please visit the QCDR page.</td></tr><tr></tr> ";
            }
            str += "<tr><td colspan=7 font style='font-weight: bold;'>Selected Measures</td></tr><tr></tr>";
            str += "<tr font style='font-weight: bold;'> <td font style='font-weight: bold;'>MeasureNumber</td><td>MeasureTitle</td><td>MeasureType</td><td>MesureTypeModifier</td><td>Registry</td><td>Domain</td><td>Speciality</td></tr>";
            using (var entity = new DNN8Entities())
            {
                listStrings = data.SelectedMeasures.Split(',').ToList();

                foreach (var item in listStrings)
                {
                    var result1 = (from v in entity.vw_QPPMeasures_With_Modality
                                   where (v.Measure_Num.ToLower() == item.ToLower())
                                   select new ExportToExcelData
                                   {
                                       MeasureTitle = v.Measure_Title,
                                       MeasureType = v.MeasureType_Desc,
                                       MesureTypeModifier = v.Measure_Type_Modifier,
                                       RegistryDescription = v.registry_Desc,
                                       Domain = v.Domain,
                                       Speciality = v.specialty_Desc,
                                       MeasureNumber = v.Measure_Num
                                   }).FirstOrDefault();
                    str += "<tr> <td>" + result1.MeasureNumber + "</td><td>" + result1.MeasureTitle + "</td> <td>" + result1.MeasureType + "</td><td>" + result1.MesureTypeModifier + "</td><td>" + result1.RegistryDescription + "</td>  <td>" + result1.Domain + "</td> <td>" + result1.Speciality + "</td> </tr>";
                }
                str += "</table>";
            }
            HttpResponseMessage result = new HttpResponseMessage(HttpStatusCode.OK);
            result.Content = new StringContent(str);
            result.Content.Headers.ContentType = new MediaTypeHeaderValue("application/vnd.xls");
            result.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment"); //attachment will force download
            result.Content.Headers.ContentDisposition.FileName = "Measuredata.xlsx";
            return result;
        }
    }
}